<?php $__env->startSection('a2'); ?>
    class="active"
<?php $__env->stopSection(); ?>

<style>
    /*Карточка профиля*/
    .cardpr {
        box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
        max-width: 250px;
        display: inline-block;
        margin: left;
        width:30%;
        text-align: center;
        font-family: arial;
        margin: 10px;

    }
    .card2 {
        background-color: white;
        display: inline-block;

    }

    .title {
        color: grey;
        font-size: 18px;
    }

    .cardpr button {
        border: none;
        outline: 0;
        display: inline-block;
        padding: 8px;
        color: white;
        background-color: #0f1226;
        text-align: center;
        cursor: pointer;
        width: 100%;
        font-size: 18px;

    }


    .cardpr button:hover, a:hover {
        opacity: 0.7;
        background-color:#171d54;
    }

</style>

<?php $__env->startSection('select1'); ?>
    <div class="form-group">

        <select class="form-control" id ="prepodselect" onchange="window.location.href = this.options[this.selectedIndex].value">
            <option value="">Выберите преподавателя:</option>
            <?php $__currentLoopData = $sh_pr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sh_pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <option value="<?php echo e(route('pr_show', $sh_pr->Преподаватель)); ?>"><?php echo e($sh_pr->Преподаватель); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>

        <div class="card2">

            <?php $__currentLoopData = $prepods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prepods): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div   class="cardpr">
                <img src="https://us.123rf.com/450wm/feelisgood/feelisgood1709/feelisgood170900745/85757402-flat-user-icon-member-sign-avatar-button-quick-and-easy-recolorable-shape-isolated-from-background-v.jpg?ver=6"
                     alt="Преподаватель" style="width:100%">
                <h3><?php echo e($prepods->Фамилия); ?> <?php echo e($prepods->Имя); ?> <?php echo e($prepods->Отчество); ?></h3>
                <p class="title">Email: qwerty@mail.ru</p>
                <p>Тел.: 8-991-123-43-23</p>
                <form action="<?php echo e(route('rasp_pr', $prepods->Преподаватель)); ?>">
                <p><button>Показать Расписание</button></p>
                </form>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('shablontimetable', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\timetable\resources\views/prepod.blade.php ENDPATH**/ ?>