<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="utf-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<style>






body {
    font-family: Arial;
    padding: 0px;
    background:white;
}


.header {
    padding: 30px;
    font-size: 40px;
    text-align: center;
    background: white;
}





.card {
     background-color: white;
     padding: 50px 200px;

}





.icon-bar {
    width: 100%;
    background-color: #0f1226;
    overflow: auto;
}


.icon-bar a {
    float: right;
    width: 15%;
    text-align: center;
    padding: 20px 0;
    transition: all 0.3s ease;
    color: white;
    font-size: 20px;
text-decoration: none;
}


.icon-bar a:hover {
    background-color: #171d54;
}

.active {
    background-color: #171d54; 
}

.tab {
    overflow: hidden;
    border: 1px solid #ccc;
    background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
    background-color: inherit;
    float: center;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
    background-color: #171d54;
color: white;
}

/* Create an active/current tablink class */
.tab button.active {
    background-color: #171d54;
color: white;
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}

.table-striped > tbody > tr:nth-child(2n+1) > td, .table-striped > tbody > tr:nth-child(2n+1) > th {
   background-color: #ebecf5;
}

</style>
<head>

<div class="icon-bar">

  <a href="vhod.html#">Вход</a> 
  <a href="kon.html#">Контакты</a> 
  <a href="ay.html#">Расписание Аудиторий</a>
  <a href="pr.html#">Расписание Преподователей</a> 
  <a class="active" href="gr.html#">Расписание Групп</a> 
<a style=" float: left" href="https://www.tspu.edu.ru/"><img src="image/logo.png" width="50" 
   height="30"  alt=""></a>
 
</div>

</head>
</html><?php /**PATH C:\xampp\htdocs\testlaravel\resources\views/shapka.blade.php ENDPATH**/ ?>