
<div class="card">
<div class="tab">


    <button class="tablinks" onclick="openDen(event, 'Pon')"><h3>Понедельник</h3></button>
    <button class="tablinks" onclick="openDen(event, 'Vt')"><h3>Вторник</h3></button>
    <button class="tablinks" onclick="openDen(event, 'Sr')"><h3>Среда</h3></button>
    <button class="tablinks" onclick="openDen(event, 'Cht')"><h3>Четверг</h3></button>
    <button class="tablinks" onclick="openDen(event, 'Pt')"><h3>Пятница</h3></button>
    <button class="tablinks" onclick="openDen(event, 'Sb')"><h3>Суббота</h3></button>
</div>

    <?php echo $__env->yieldContent('raspisanie'); ?>
</div>





<script>
    function openDen(evt, cityName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
    }
</script>
<?php /**PATH C:\xampp\htdocs\timetable\resources\views/shablontable.blade.php ENDPATH**/ ?>